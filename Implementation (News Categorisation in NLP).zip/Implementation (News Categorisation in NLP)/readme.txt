Structure Summary of Entire Unzipped Folder:
- readme.txt (this file)
- majority_class_baseline.ipynb (notebook to run majority class baseline)
- svm.ipynb (notebook to run svm)
- bert.ipynb (notebook to run bert)
- Data (folder with datasets)
--- train.csv (training dataset)
--- test.csv (testing dataset)
- Model (folder with pre-trained models)
--- majority_class_baseline_model.joblib (pretrained majority class baseline model to be automatically loaded in corresponding notebook)
--- svm_model.joblib (pretrained msvm model to be automatically loaded in corresponding notebook)
--- bert.pth (pre-trained bert states to be automatically loaded in corresponding notebook) (NEED TO BE DOWNLOADED AT https://drive.google.com/file/d/1-YIPwDfXeUbFeSghpqAPcw9YSbR0mRCf/view?usp=share_link and put in the 'Model' folder)

Instruction:
1. Please download 'bert.pth' at https://drive.google.com/file/d/1-YIPwDfXeUbFeSghpqAPcw9YSbR0mRCf/view?usp=share_link , and put it into the 'Model' folder.
2. Notebooks can be directly 'run all', with pre-trained models or model states being automatically loaded.
2. Required libraries and modules are indicated and imported in the first few cells of notebooks.
4. Entire unzipped folder can be run offline.